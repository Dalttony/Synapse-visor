package com.example.reconocimiento.data.repository.impl;

public class RecognitionRepositoryImpl {
}
